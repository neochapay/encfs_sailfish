#!/bin/bash

set -eu

if [ ! -d INSTALL ]
then
	mkdir INSTALL
fi

if [ -d BUILD ]
then

cd BUILD
echo ====================
ls
echo ====================

make DESTDIR =./INSTALL install

else

echo "need build before install"

fi


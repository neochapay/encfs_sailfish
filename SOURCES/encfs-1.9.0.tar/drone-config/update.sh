docker build -t encfs_drone .

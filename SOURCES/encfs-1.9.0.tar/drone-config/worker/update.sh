docker build -t encfs_worker .

#!/bin/bash

set -eu

if [ ! -d BUILD ]
then
	mkdir BUILD
	mkdir INSTALL
	cd BUILD
	
else
	cd BUILD
	
fi
cmake .. -DCMAKE_INSTALL_PREFIX=/usr

make

